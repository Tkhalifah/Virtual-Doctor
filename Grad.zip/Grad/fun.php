<?php

  include "connect.php";

  function displayList(){//list of search
    $sql="SELECT * FROM symptoms ";
  	$result=mysqli_query($GLOBALS['con'],$sql);
    $count=mysqli_num_rows($result);
    echo "<datalist id=\"symptoms\">";
    while($row =mysqli_fetch_assoc($result)){
      echo "<option value=".$row['Name']."></option>";
    }
    echo "</datalist>";
  }

  function getIdsymptoms($name){ //get id from name
    $sql="SELECT * FROM `symptoms` where `Name`='$name'";
  	$result=mysqli_query($GLOBALS['con'],$sql);
    $count=mysqli_num_rows($result);
    $row =mysqli_fetch_assoc($result);
    if($count===1){
      return $row['sid'];
    }
  }

  function symptoms($activities){ //fun is work
    $Symp_Array = explode("*",$activities);
    //print_r($Symp_Array);echo "<br/>";
    for($i=0;$i<count($Symp_Array)-1;$i++){
      $Symp_Array[$i]=getIdsymptoms($Symp_Array[$i]);
    }
    unset($Symp_Array[count($Symp_Array)-1]);
    //print_r($Symp_Array);echo "<br/>";echo "<br/>";
    $command=exec('python Model.py ' . escapeshellarg(json_encode($Symp_Array)) .'2<&1',$output);
    //echo "<br/>";
    //print_r($output);
    if(!feedback($Symp_Array)){
      echo "
      <script type=\"text/javascript\">
      swal(\"Error!!!!\" ,\" \", \" WARNING\");
                        </script>

      ";
    }else{
      echo "
      <div class=\"progress\" id=\"prog\">
  		    <div class=\"progress-bar progress-bar-danger\" role=\"progressbar\" style=\"width:".$output[1]."%\">
          ".$output[0]." ".$output[1]." %
  		    </div>
  		    <div class=\"progress-bar progress-bar-warning\" role=\"progressbar\" style=\"width:".$output[3]."%\">
  		      ".$output[2]." ".$output[3]." %
  		    </div>
  		    <div class=\"progress-bar progress-bar-success\" role=\"progressbar\" style=\"width:".$output[5]."%\">
  		      ".$output[4]." ".$output[5]." %
  		    </div>
  		  </div>
      ";
    }

  }

  function feedback($Symp_Array){
    //time
    date_default_timezone_set('Africa/Cairo');
    $current_date = date('Y-m-d h:i:s');
    //idUser
    $idUser=$_SESSION['usrId'];
    //id
    $idSep= array(10);
    for($i=0;$i<10;$i++){
      if(!isset($Symp_Array[$i])){
        $idSep[$i]=2147483647;
      }else {
        $idSep[$i]=$Symp_Array[$i];
      }
    }
    // print_r($Symp_Array);
    print_r($idSep);
    $sql="INSERT INTO `check_up`(`date`, `usid`, `syid`, `symid1`, `symid2`, `symid3`, `symid4`, `symid5`, `symid6`, `symid7`, `symid8`, `symid9`)
    VALUES ('$current_date','$idUser','$idSep[0]','$idSep[1]','$idSep[2]','$idSep[3]','$idSep[4]',
      '$idSep[5]','$idSep[6]','$idSep[7]','$idSep[8]','$idSep[8]')";
    $query=mysqli_query($GLOBALS['con'],$sql);
    if($query===false){
      return 0;
    }else {
      return 1;
    }


  }








?>
